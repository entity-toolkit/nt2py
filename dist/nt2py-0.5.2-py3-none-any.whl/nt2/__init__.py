__version__ = "0.5.2"

from nt2.data import Data as Data
from nt2.dashboard import Dashboard as Dashboard
