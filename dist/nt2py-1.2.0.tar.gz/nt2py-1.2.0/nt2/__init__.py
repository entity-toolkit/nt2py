__version__ = "1.2.0"

import nt2.containers.data as nt2_data


class Data(nt2_data.Data):
    pass
