import warnings


class FutureDeprecationWarning(Warning):
    pass
