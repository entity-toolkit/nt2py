__version__ = "0.6.0"

from nt2.data import Data as Data
from nt2.dashboard import Dashboard as Dashboard
