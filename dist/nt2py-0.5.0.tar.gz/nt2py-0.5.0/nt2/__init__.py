__version__ = "0.5.0"

from nt2.data import Data as Data
